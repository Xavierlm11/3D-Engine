# 3D-Engine

https://github.com/Xavierlm11/Omega-Engine

The goal of this project is to make a game engine which can be used to develop 3D games.

We hope you like it! :)

For now, our engine is capable of rendering FBXs files that are dragged & dropped in. 
There are 3 modes of rendering: Normal, with checkers view and Wireframe.
Also, there are other settings in the view like fog.

The meshes are grouped in a game object system with parents and children.
Finally, if the file has attached a texture, the engine will automatically set a meterial with it in the game object.

We are:
Xavier Casadó - https://github.com/Akage369
Xavier López - https://github.com/Xavierlm11

The camera uses WS to move front and backwards, AD to move laterally and EC to move up and down.
Also, you can scroll the mouse wheel to zoom in or zoom out.
Right click to rotate the camera and Shift + left click to rotate around the a game object.





